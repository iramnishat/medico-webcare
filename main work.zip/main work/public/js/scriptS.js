console.log("script running...")
document.querySelector('.cross').style.display='none';
document.querySelector('.togglee').addEventListener("click",()=>{
    document.querySelector('.sidebar').classList.toggle('sidebargo');

})
document.querySelector('.cross1').style.display='none';
document.querySelector('.togglee1').addEventListener("click",()=>{
    document.querySelector('.sidebar1').classList.toggle('sidebargo1');

})